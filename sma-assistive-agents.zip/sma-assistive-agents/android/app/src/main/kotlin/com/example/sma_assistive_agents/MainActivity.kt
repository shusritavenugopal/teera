package com.example.sma_assistive_agents

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
