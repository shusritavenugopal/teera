import 'package:flutter/material.dart';
import 'chatbot_client.dart';

class AwarenessGuidePage extends StatefulWidget {
  @override
  _AwarenessGuidePageState createState() => _AwarenessGuidePageState();
}

class _AwarenessGuidePageState extends State<AwarenessGuidePage> {
  final _chatController = TextEditingController();
  final _chatClient = ChatbotClient(
    projectId: 'total-apparatus-410817',
    agentId: '1387d9a4-f42d-43cf-87f2-b6a0a601ba40',
    location: 'us-central1',
  );

  List<String> _messages = [];

  void _sendMessage() async {
    final message = _chatController.text;
    if (message.isEmpty) return;

    setState(() {
      _messages.add('You: $message');
    });

    final response = await _chatClient.sendMessage('1', message);
    print(response);
    setState(() {
      _messages.add('General Awareness: $response');
    });

    _chatController.clear();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('General Awareness'),
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              itemCount: _messages.length,
              itemBuilder: (context, index) {
                return ListTile(
                  title: Text(_messages[index]),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _chatController,
                    decoration: InputDecoration(hintText: 'Do you have any general questions about SMA?'),
                  ),
                ),
                IconButton(
                  icon: Icon(Icons.send),
                  onPressed: _sendMessage,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
} 