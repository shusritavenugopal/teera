import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:provider/provider.dart';
import 'firebase_options.dart';
import 'nutritional_guide_page.dart';
import 'package:go_router/go_router.dart';
import 'support_guide_page.dart';
import 'awareness_guide_page.dart';
import 'cognition_guide_page.dart';
import 'chatbot_client.dart';


void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    final GoRouter _router = GoRouter(
      routes: [
        GoRoute(
          path: '/',
          builder: (context, state) => MyHomePage(),
        ),
        GoRoute(
          path: '/support',
          builder: (context, state) => SupportGuidePage(),
        ),
        GoRoute(
          path: '/awareness',
          builder: (context, state) => AwarenessGuidePage(),
        ),
        GoRoute(
          path: '/nutrition',
          builder: (context, state) => NutritionalGuidePage(),
        ),
        GoRoute(
          path: '/cognition',
          builder: (context, state) => CognitionGuidePage(),
        ),
        GoRoute(
          path: '/community',
          builder: (context, state) => EmotionalGuidePage(),
        ),
      ],
    );
    const String appTitle = 'SMA Assistive App';
    // const String pageTitle = 'Google Gemini Powered Assistive App for SMA Parents';
    return ChangeNotifierProvider(
      create: (context) => MyAppState(),
      child: MaterialApp.router(
        title: appTitle,
        routerConfig: _router,
      ),
    );
  }
}

class MyAppState extends ChangeNotifier {

} 

class MyHomePage extends StatefulWidget {
  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  var selectedIndex = 0;

  @override
  Widget build(BuildContext context) {
    Widget page;
    switch (selectedIndex) {
      case 0:
        page = HomePage();
        break;
      case 1:
        page = AwarenessGuidePage();
        break;
      case 2:
        page = NutritionalGuidePage();
        break;
      case 3:
        page = CognitionGuidePage();
        break;
      case 4:
        page = EmotionalGuidePage();
        break;
      default:
        throw UnimplementedError('no widget for $selectedIndex');
    }

    return LayoutBuilder(builder: (context, constraints) {
      return Scaffold(
          body: 
            Column(
              children: [
                SafeArea(
                  child: NavigationBar(
                    destinations: [
                      NavigationDestination(
                        icon: Icon(Icons.home),
                        label: 'Home',
                      ),
                      NavigationDestination(
                        icon: Icon(Icons.info),
                        label: 'Awareness',
                      ),
                      NavigationDestination(
                        icon: Icon(Icons.fastfood_rounded),
                        label: 'Nutrition',
                      ),
                      NavigationDestination(
                        icon: Icon(Icons.local_library),
                        label: 'Cognition',
                      ),
                      NavigationDestination(
                        icon: Icon(Icons.diversity_1),
                        label: 'Community',
                      )
                    ],
                    selectedIndex: selectedIndex,
                    onDestinationSelected: (value) {
                      setState(() {
                        selectedIndex = value;
                      });
                    },
                  ),
                ),
                Expanded(
                  child: page,
                ),
              ],
            ),
        );
    });
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    const String pageTitle = 'Teera - Assistive App for SMA Parents Powered by Google Vertex AI';

    return Scaffold(
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(100.0), // Increase the height as needed
        child: AppBar(
          title: Padding(
            padding: const EdgeInsets.symmetric(vertical: 30.0), // Add padding here
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                SelectableText(
                  pageTitle,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontSize: 24.0, // Adjust the font size as needed
                    color: Color.fromARGB(255, 231, 226, 247),
                  ),
                ),
              ],
            ),
          ),
          backgroundColor: const Color.fromARGB(255, 33, 5, 77),
          centerTitle: true,
          elevation: 2,
          iconTheme: const IconThemeData(color: Color(0xFF4A484F)),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Card(
              elevation: 2,
              margin: const EdgeInsets.only(bottom: 16.0),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'About SMA...',
                      style: Theme.of(context).textTheme.headlineMedium,
                    ),
                    const Divider(),
                    RichText(
                      text: TextSpan(
                        style: Theme.of(context).textTheme.bodyMedium,
                        children: [
                          TextSpan(
                            text: 'Spinal muscular atrophy (SMA) is a rare, inherited neuromuscular disorder that causes muscle weakness and wasting. '
                          ),
                          TextSpan(
                            text: 'SMA is usually diagnosed in infancy or early childhood and raising a child with special needs can be demanding. There\'s a lot of information to manage and specific care needs.\n\n',
                          ),
                          TextSpan(
                            text: 'That\'s why we created Teera, ',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                          TextSpan(
                            text: 'an assistive agent app designed specifically for parents of children with SMA. Teera is here to support you every step of the way, making it easier to manage your child\'s care and connect with resources and communities that understand your journey.',
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Card(
              elevation: 2,
              margin: const EdgeInsets.only(bottom: 16.0),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'How can Teera help?',
                      style: Theme.of(context).textTheme.headlineMedium,
                    ),
                    const SizedBox(height: 8.0),
                    ListTile(
                      leading: const Icon(Icons.info, color: Colors.blue),
                      title: Text(
                        'Teera helps you gain a better understanding of SMA, providing essential information to increase your awareness and knowledge about the condition.',
                        style: Theme.of(context).textTheme.bodyMedium,
                      ),
                    ),
                    ListTile(
                      leading: const Icon(Icons.fastfood, color: Colors.green),
                      title: Text(
                        'Learn about the nutritional guidelines tailored for your child\'s needs, ensuring they receive the best possible care for their condition.',
                        style: Theme.of(context).textTheme.bodyMedium,
                      ),
                    ),
                    ListTile(
                      leading: const Icon(Icons.local_library, color: Colors.orange),
                      title: Text(
                        'Explore different methods and techniques to aid in your child\'s learning and development, tailored to their unique needs.',
                        style: Theme.of(context).textTheme.bodyMedium,
                      ),
                    ),
                    ListTile(
                      leading: const Icon(Icons.group, color: Colors.purple),
                      title: Text(
                        'Connect with a supportive community of other SMA parents and caregivers, sharing experiences, advice, and encouragement.',
                        style: Theme.of(context).textTheme.bodyMedium,
                      ),
                    ),
                    const ButtonSection(),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class TitleSection extends StatelessWidget {
  const TitleSection({
    super.key,
    required this.name,
    required this.location,
  });

  final String name;
  final String location;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Row(
        children: [
          Expanded(
            /*1*/
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                /*2*/
                Padding(
                  padding: const EdgeInsets.only(bottom: 5),
                  child: SelectableText(
                    name,
                    style: TextStyle(
                      fontWeight: FontWeight.w900,
                      fontSize: 22,
                      color: Color.fromARGB(255, 74, 72, 79),
                    ),
                  ),
                ),
                SelectableText(
                  location,
                  style: TextStyle(
                    fontWeight: FontWeight.w400,
                    fontSize: 18,
                    color: Color.fromARGB(255, 74, 72, 79),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class ButtonSection extends StatelessWidget {
  const ButtonSection({super.key});

  @override
  Widget build(BuildContext context) {
    final Color color = Theme.of(context).primaryColor;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 16.0),
      child: Wrap(
        spacing: 16.0, // horizontal spacing between buttons
        runSpacing: 16.0, // vertical spacing between rows
        alignment: WrapAlignment.center,
        children: [
          ElevatedButton(
            onPressed: () {
              GoRouter.of(context).go('/support');
            },
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: const [
                Icon(Icons.info),
                SizedBox(width: 8),
                Text('Ask Me Anything'),
              ],
            ),
          ),
          ElevatedButton(
            onPressed: () {
              GoRouter.of(context).go('/awareness');
            },
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: const [
                Icon(Icons.info),
                SizedBox(width: 8),
                Text('Awareness Guide'),
              ],
            ),
          ),
          ElevatedButton(
            onPressed: () {
              GoRouter.of(context).go('/nutrition');
            },
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: const [
                Icon(Icons.fastfood_rounded),
                SizedBox(width: 8),
                Text('Nutritional Guide'),
              ],
            ),
          ),
          ElevatedButton(
            onPressed: () {
              GoRouter.of(context).go('/cognition');
            },
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: const [
                Icon(Icons.local_library),
                SizedBox(width: 8),
                Text('Cognition Guide'),
              ],
            ),
          ),
          ElevatedButton(
            onPressed: () {
              GoRouter.of(context).go('/community');
            },
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: const [
                Icon(Icons.diversity_1),
                SizedBox(width: 8),
                Text('Community Support'),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class TextSection extends StatelessWidget {
  const TextSection({
    super.key,
    required this.description
  });

  final String description;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(32),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SelectableText(
            description,
            style: TextStyle(
              fontWeight: FontWeight.w400,
              fontSize: 18,
              color: Color.fromARGB(255, 74, 72, 79),
            ),
          ),
          SizedBox(height: 16), // Add some space between the texts if needed
        ],
      ),
    );
  }
}

class ButtonWithText extends StatelessWidget {
  const ButtonWithText({
    super.key,
    required this.color,
    required this.icon,
    required this.label,
  });

  final Color color;
  final IconData icon;
  final String label;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Icon(icon, color: color),
        Padding(
          padding: const EdgeInsets.only(top: 8),
          child: Text(
            label,
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w400,
              color: color,
            ),
          ),
        ),
      ],
    );
  }
}

class EmotionalGuidePage extends StatefulWidget {
  @override
  _EmotionalGuidePageState createState() => _EmotionalGuidePageState();
}

class _EmotionalGuidePageState extends State<EmotionalGuidePage> {
  final _chatController = TextEditingController();
  final _chatClient = ChatbotClient(
    projectId: 'your-project-id',
    agentId: 'your-agent-id',
    location: 'your-agent-location',
  );

  List<String> _messages = [];

  void _sendMessage() async {
    final message = _chatController.text;
    if (message.isEmpty) return;

    setState(() {
      _messages.add('You: $message');
    });

    final response = await _chatClient.sendMessage('1', message);
    print(response);
    setState(() {
      _messages.add('Bot: $response');
    });

    _chatController.clear();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Chatbot'),
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              itemCount: _messages.length,
              itemBuilder: (context, index) {
                return ListTile(
                  title: Text(_messages[index]),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _chatController,
                    decoration: InputDecoration(hintText: 'Type a message'),
                  ),
                ),
                IconButton(
                  icon: Icon(Icons.send),
                  onPressed: _sendMessage,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}