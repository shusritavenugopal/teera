import 'package:flutter/material.dart';
import 'chatbot_client.dart';


class CognitionGuidePage extends StatefulWidget {
  @override
  _CognitionGuidePageState createState() => _CognitionGuidePageState();
}

class _CognitionGuidePageState extends State<CognitionGuidePage> {
  final _chatController = TextEditingController();
  final _chatClient = ChatbotClient(
    projectId: 'total-apparatus-410817',
    agentId: 'a73cba1a-1652-41e7-8809-42b5a0536094',
    location: 'us-central1',
  );

  List<String> _messages = [];

  void _sendMessage() async {
    final message = _chatController.text;
    if (message.isEmpty) return;

    setState(() {
      _messages.add('You: $message');
    });

    final response = await _chatClient.sendMessage('1', message);
    print(response);
    setState(() {
      _messages.add('Bot: $response');
    });

    _chatController.clear();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Chatbot'),
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              itemCount: _messages.length,
              itemBuilder: (context, index) {
                return ListTile(
                  title: Text(_messages[index]),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _chatController,
                    decoration: InputDecoration(hintText: 'Type a message'),
                  ),
                ),
                IconButton(
                  icon: Icon(Icons.send),
                  onPressed: _sendMessage,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}