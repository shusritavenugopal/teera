import 'package:flutter/material.dart';
import 'chatbot_client.dart';


class SupportGuidePage extends StatefulWidget {
  @override
  _SupportGuidePageState createState() => _SupportGuidePageState();
}

class _SupportGuidePageState extends State<SupportGuidePage> {
  final _chatController = TextEditingController();
  final _chatClient = ChatbotClient(
    projectId: 'total-apparatus-410817',
    agentId: '30e566ce-9bf0-4728-ab02-1c050c69f2df',
    location: 'us-central1',
  );

  List<String> _messages = [];

  void _sendMessage() async {
    final message = _chatController.text;
    if (message.isEmpty) return;

    setState(() {
      _messages.add('You: $message');
    });

    final response = await _chatClient.sendMessage('1', message);
    print(response);
    setState(() {
      _messages.add('Support Bot: $response');
    });

    _chatController.clear();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Ask Me Anything'),
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              itemCount: _messages.length,
              itemBuilder: (context, index) {
                return ListTile(
                  title: Text(_messages[index]),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _chatController,
                    decoration: InputDecoration(hintText: 'Type a message'),
                  ),
                ),
                IconButton(
                  icon: Icon(Icons.send),
                  onPressed: _sendMessage,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}