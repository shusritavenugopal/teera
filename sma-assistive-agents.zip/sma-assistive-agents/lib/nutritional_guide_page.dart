import 'package:flutter/material.dart';
import 'chatbot_client.dart';

class NutritionalGuidePage extends StatefulWidget {
  @override
  _NutritionalGuidePageState createState() => _NutritionalGuidePageState();
}

class _NutritionalGuidePageState extends State<NutritionalGuidePage> {
  final _chatController = TextEditingController();
  final _chatClient = ChatbotClient(
    projectId: 'total-apparatus-410817',
    agentId: 'fe33219b-9f62-4b75-9336-5671eae6e883',
    location: 'us-central1',
  );

  List<String> _messages = [];

  void _sendMessage() async {
    final message = _chatController.text;
    if (message.isEmpty) return;

    setState(() {
      _messages.add('You: $message');
    });

    final response = await _chatClient.sendMessage('1', message);
    print(response);
    setState(() {
      _messages.add('Nutrition Guide: $response');
    });

    _chatController.clear();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Nutrition Guide'),
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              itemCount: _messages.length,
              itemBuilder: (context, index) {
                return ListTile(
                  title: Text(_messages[index]),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _chatController,
                    decoration: InputDecoration(hintText: 'Ask about nutrition guilines for SMA kids...'),
                  ),
                ),
                IconButton(
                  icon: Icon(Icons.send),
                  onPressed: _sendMessage,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
} 